
import streamlit as st

st.set_page_config(page_title="NutriSync", layout="wide")

st.title("🥗 NutriSync")

# -------- PERFIL --------
st.sidebar.header("Seu Perfil")

peso = st.sidebar.number_input("Peso (kg)", value=80.0)
altura = st.sidebar.number_input("Altura (cm)", value=180.0)
idade = st.sidebar.number_input("Idade", value=25)
sexo = st.sidebar.selectbox("Sexo", ["Masculino", "Feminino"])
objetivo = st.sidebar.selectbox("Objetivo", ["Emagrecer", "Manter", "Ganhar massa"])

# -------- CÁLCULOS --------
altura_m = altura / 100
imc = peso / (altura_m ** 2)

if sexo == "Masculino":
    tmb = 10*peso + 6.25*altura - 5*idade + 5
else:
    tmb = 10*peso + 6.25*altura - 5*idade - 161

gasto = tmb * 1.5

if objetivo == "Emagrecer":
    meta = gasto - 500
elif objetivo == "Ganhar massa":
    meta = gasto + 300
else:
    meta = gasto

proteina_meta = peso * 2

# -------- DASHBOARD --------
st.subheader("📊 Seus Dados")

col1, col2, col3 = st.columns(3)
col1.metric("IMC", round(imc,1))
col2.metric("Calorias meta", int(meta))
col3.metric("Proteína meta (g)", int(proteina_meta))

# -------- REGISTRO DO DIA --------
st.subheader("🍽️ Seu Dia")

calorias = st.number_input("Calorias consumidas hoje", 0)
proteina = st.number_input("Proteína consumida hoje (g)", 0)
agua = st.number_input("Água (ml)", 0)

# -------- PROGRESSO --------
st.subheader("📈 Progresso")

st.write("Calorias")
st.progress(min(calorias/meta,1.0))
st.write(f"{calorias} / {int(meta)} kcal")

st.write("Proteína")
st.progress(min(proteina/proteina_meta,1.0))
st.write(f"{proteina} / {int(proteina_meta)} g")

# -------- FEEDBACK --------
st.subheader("🤖 Feedback Inteligente")

if proteina < proteina_meta:
    st.warning("⚠️ Você precisa consumir mais proteína hoje")
else:
    st.success("✅ Proteína batida!")

if calorias > meta:
    st.error("🔥 Você passou das calorias")
else:
    st.info("👍 Dentro da meta")

if agua < 2000:
    st.warning("💧 Beba mais água")
else:
    st.success("💧 Hidratação ok")
